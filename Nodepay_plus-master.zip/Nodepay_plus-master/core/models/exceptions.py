class CloudflareException(Exception):
    pass

class LoginError(Exception):
    pass

class MineError(Exception):
    pass

class TokenError(Exception):
    pass
